<?php
@session_start();
if ($_SESSION['submitted']) {
    $_SESSION['submitted'] = false;
    header('location:Layout_form.php');
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Theme Generator</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="jscolor.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600" rel="stylesheet">
    <style>
        body {
            background-image: url("texture-tutorial-9.jpg");
        }

        * {
            font-family: 'Nunito Sans', sans-serif;
        }
    </style>
</head>
<body>
<h3 class="text-center" style="background-color: white;padding: 20px;font-family: Bavro;font-weight: bold;letter-spacing: 2px;font-size: 30px;width: 70%;margin: 20px auto 30px auto;border-radius: 5px;">CSS THEME GENERATOR</h3>
<div class="container" style="background-color: white; width: 70%; padding:0 5%; border-radius: 5px;margin: 20px auto;">
    <br>
    <h4 style="font-style: italic;">Select following options to create a layout : </h4>
    <br>

    <form action="Layout_check.php" method="post">
        <div class="row panel panel-default text-center">
            <div class="col-md-4 form-group" style="margin-bottom: 0">
                <label for="doctype" class=" panel-body" style="padding: 10px;">DOCTYPE</label>
                <input type="text" id="doctype" style="vertical-align: 0px;border-width: 2px;" placeholder="HTML"
                       disabled>
            </div>
            <div class="col-md-4 form-group" style="margin-bottom: 0">
                <label for="html" class="active panel-body" style="padding: 10px;">HTML</label>
                <input type="radio" id="html" checked="" style="vertical-align: -2px;" name="HTML">
            </div>
            <div class="col-md-4 form-group" style="margin-bottom: 0">
                <label for="head" class="active panel-body" style="padding: 10px;">HEAD</label>
                <input type="radio" id="head" checked="" style="vertical-align: -2px;">
            </div>
        </div>
        <br>
        <div class="row form-group">
            <div class="col-md-3 ">
                <label for="title" style="font-size: 20px;">Enter the title: </label>
            </div>
            <div class="col-md-9">
                <input type="text" id="title" name="title" class="form-control" placeholder="Enter title"
                       value="Layout">
            </div>
        </div>
        <br>
        <div class="row form-group panel panel-default">
            <p style="margin-bottom: 0;padding: 20px; font-size: larger;">CONTAINER&nbsp</p>
            <div class="col-md-3 text-center" style="font-size: larger;">
                <div class="form-group radio" style="margin-bottom: 20px;">
                    <label for="fixed"><input type="radio" name="container_type" id="fixed" style="vertical-align: 0;"
                                              checked="" value="Fixed">Fixed</label>
                </div>
                <div class="form-group radio" style="margin-left: -5px;">
                    <label for="fluid"><input type="radio" name="container_type" id="fluid" style="vertical-align: 0;"
                                              value="Fluid"
                        >Fluid</label>
                </div>
            </div>
            <div class="col-md-9 text-center">
                <div class="test1">
                    <div class="row" style="margin-bottom: 30px;">
                        <div class="col-md-2" style="margin-top: 3px;font-size: larger;text-align: left;">Width:</div>
                        <div class="input-group col-md-9">
                            <input id="container_width" type="number" min="500" max="1350"
                                   class="form-control form-inline" name="container_width"
                                   placeholder="Width of container" value="1000">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2" style="margin-top: 0px;font-size: larger;">Alignment:</div>
                        <div class="col-md-9" style="font-size: larger;">
                            <div class="radio-inline" style="width: 30%">
                                <label><input type="radio" name="cont_align" checked="" value="Center">Center</label>
                            </div>
                            <div class="radio-inline" style="width: 30%;">
                                <label><input type="radio" name="cont_align" value="Left">Left</label>
                            </div>
                            <div class="radio-inline" style="width: 30%">
                                <label><input type="radio" name="cont_align" value="Right">Right</label>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <div class="test2">
                    <div class="row" style="margin-bottom: 30px;">
                        <div class="col-md-3" style="margin-top: 3px;font-size: larger;text-align: left;">Max-width:
                        </div>
                        <div class="input-group col-md-8">
                            <input id="container_width" type="text" class="form-control form-inline" name="max-width"
                                   placeholder="Width of container" value="1500">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom: 30px;">
                        <div class="col-md-3" style="margin-top: 3px;font-size: larger;text-align: left;">Min-width:
                        </div>
                        <div class="input-group col-md-8">
                            <input id="container_width" type="text" class="form-control form-inline" name="min-width"
                                   placeholder="Width of container" value="1000">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <br>
                </div>
            </div>
        </div>
        <br>
        <div class="row form-group panel panel-default">
            <p style="margin-bottom: 0;padding: 20px; font-size: larger;">HEADER&nbsp</p>
            <label style="padding: 0 20px;margin: 0;font-size: 15px;" for="navcheck">Do you want a header?</label>
            <input type='hidden' value='0' name='nav_check'>
            <input type="checkbox" id="navcheck" style="margin-bottom: 20px;" name="nav_check" value='1'>
            <div class="navc">
                <div class="row" style="padding: 20px;">
                    <div class="col-md-6">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Height:</div>
                        <div class="input-group ">
                            <input type="number" max="100" class="form-control form-inline" name="nav_height"
                                   placeholder="Height of navbar" value="30">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <div class="col-md-6" style="padding: 0 0 0 15%;">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Color:</div>
                        <div class="input-group">
                            <input type="text" class="form-control form-inline jscolor" style="border-radius: 4px;"
                                   name="nav_color" value="#45E6BD">
                        </div>
                    </div>
                </div>
                <label style="padding: 0 20px;margin: 0;font-size: 15px;" for="navmenu">Include header-menu?</label>
                <input type='hidden' value='0' name='nav_menu'>
                <input type="checkbox" id="navmenu" name="nav_menu" value='1'>
                <br><br>
            </div>
        </div>
        <div class="row form-group panel panel-default">
            <p style="margin-bottom: 0;padding: 20px; font-size: larger;">SIDE-MENU&nbsp</p>
            <label style="padding: 0 20px;margin: 0;font-size: 15px;" for="sidemenu_check">Do you want a side
                menu??</label>
            <input type='hidden' value='0' name='side_check'>
            <input type="checkbox" id="sidemenu_check" value='1' style="margin-bottom: 20px;" name="side_check">
            <div class="sidec">
                <div class="row" style="padding: 20px;">
                    <div class="col-md-6">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Width:</div>
                        <div class="input-group ">
                            <input type="text" class="form-control form-inline" name="side_width"
                                   placeholder="Width of sidebar" min="150" max="400" value="200">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <div class="col-md-6" style="padding: 0 0 0 15%;">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Color:</div>
                        <div class="input-group">
                            <input type="text" class="form-control form-inline jscolor" style="border-radius: 4px;"
                                   name="side_color" value="E9967A">
                        </div>
                    </div>
                </div>
                <div class="row" style="padding: 20px;">
                    <div class="col-md-2" style="margin-top: 0px;font-size: larger;">Alignment:</div>
                    <div class="col-md-9" style="font-size: larger;">
                        <div class="radio-inline" style="width: 30%;">
                            <label><input type="radio" name="side_align" checked="" value="Left">Left</label>
                        </div>
                        <div class="radio-inline" style="width: 30%">
                            <label><input type="radio" name="side_align" value="Right">Right</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row form-group panel panel-default">
            <p style="margin-bottom: 0;padding: 20px; font-size: larger;">MAIN-CONTAINER&nbsp</p>
            <div style="padding: 0 20px;">
                <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;" class="col-md-5">Background
                    Color:
                </div>
                <div class="input-group">
                    <input class="form-control form-inline jscolor col-md-5" style="border-radius: 4px;"
                           name="main_content_color" value="#ffe4c4 ">
                </div>
                <br>
            </div>
        </div>
        <div class="row form-group panel panel-default">
            <p style="margin-bottom: 0;padding: 20px; font-size: larger;">FOOTER&nbsp</p>
            <label style="padding: 0 20px;margin: 0;font-size: 15px;" for="footcheck">Do you want a footer?</label>
            <input type='hidden' value='0' name='footer_check'>
            <input type="checkbox" id="footcheck" style="margin-bottom: 20px;" name="footer_check" value='1'>
            <div class="footc">
                <div class="row" style="padding: 20px;">
                    <div class="col-md-6">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Height:</div>
                        <div class="input-group ">
                            <input type="number" class="form-control form-inline" name="footer_height"
                                   placeholder="Height of footer" value="30">
                            <span class="input-group-addon">px</span>
                        </div>
                    </div>
                    <div class="col-md-6" style="padding: 0 0 0 15%;">
                        <div style="margin: 3px 0 10px 0;font-size: larger;text-align: left;">Color:</div>
                        <div class="input-group">
                            <input type="text" class="form-control form-inline jscolor" style="border-radius: 4px;"
                                   name="footer_color" value="#45E6BD">
                        </div>
                    </div>
                </div>
                <br><br>
            </div>
        </div>
        <div class="panel panel-default form-group row" style="padding: 20px;">
            <h3 class="text-center">Font Styling</h3>
            <br>
            <div class="row">
                <label style="font-size: larger;margin-bottom: 0;padding: 10px;" for="font" class="text-center col-md-4">FONT-STYLE&nbsp</label>
                <select name="font-style" id="font" class=" col-md-7" style="padding: 10px;">
                    <option value="'Roboto', sans-serif;">Roboto</option>
                    <option value="'Raleway', sans-serif;">Raleway</option>
                    <option value="'Fresca', sans-serif;">Fresca</option>
                    <option value="'Pacifico', cursive">Pacifico</option>
                    <option value="'Dancing Script', cursive;">Dancing Script</option>
                    <option value="'Crete Round', serif;">Crete Round</option>
                    <option value="'Comfortaa', cursive;">Comfortaa</option>
                    <option value="'Satisfy', cursive;">Satisfy</option>
                    <option value="'Yantramanav', sans-serif;">Yantramanav</option>
                    <option value="'Oxygen', sans-serif;">Oxygen</option>
                </select>
            </div>
            <br>
            <div class="row" >
                <label style=" font-size: larger;margin-bottom: 0; padding: 10px;" class="text-center col-md-4">FONT-SIZE&nbsp</label>
                <div class="input-group col-md-7 ">
                    <input id="font-size" type="number"
                           class="form-control form-inline " name="font-size"
                           placeholder="Font-size of text" value="16" style="padding: 20px;">
                    <span class="input-group-addon">px</span>
                </div>
            </div>
        </div>
        <br>
        <div class="row form-group ">
            <button class="btn btn-success form-control">Submit</button>
        </div>
        <br>
    </form>
</div>
<script>
    $(document).ready(function () {
        $('.test2').hide();
        $('.navc').hide();
        $('.footc').hide();
        $('.sidec').hide();
        $("#fixed").click(function () {
            $(".test2").hide();
            $(".test1").show();
        });
        $("#fluid").click(function () {
            $(".test2").show();
            $(".test1").hide();
        });
        $("#navcheck").click(function () {
            $(".navc").toggle();
        });
        $("#footcheck").click(function () {
            $(".footc").toggle();
        });
        $("#sidemenu_check").click(function () {
            $(".sidec").toggle();
        });
    });
</script>
</body>
</html>
