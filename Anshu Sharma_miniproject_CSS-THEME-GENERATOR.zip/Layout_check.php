<?php
@session_start();

//If content was sent?
if (count($_POST) > 0) {
    //File open
    $show = fopen("Layout_show.html", "w") or die("Unable to open file!");
    $style = fopen("Layout_style.css", "w");
    //Default tags to be there
    fwrite($show, "<!DOCTYPE html>\n<html>\n");

    //Adding title!
    if (count($_POST['title']) > 0 && array_key_exists('title', $_POST)) {
        $title = $_POST['title'];

        fwrite($show, "<head>\n<title>" . $title . "</title>\n<link rel=\"stylesheet\" href=\"Layout_style.css\">\n<link href=\"https://fonts.googleapis.com/css?family=Comfortaa|Crete+Round|Dancing+Script|Fresca|Oxygen|Pacifico|Raleway|Roboto|Satisfy|Yantramanav\" rel=\"stylesheet\">\n</head>\n");
    }

    //Adding font-style and font-size
    $fontstyle=$_POST['font-style'];
    $fontsize=$_POST['font-size'];
    fwrite($style,"*{\nfont-family:".$fontstyle.";\nfont-size:".$fontsize."px;\n}\n");

    fwrite($show, "<body>\n<div class=\"maincontainer\">\n");
    //Setting Container parameters
    //If container is set to be fixed
    $container_width = $_POST['container_width'];
    if ($_POST['container_type'] == "Fixed") {
        fwrite($style, ".maincontainer{\nwidth: " . $container_width . "px;\n");
        if ($_POST['cont_align'] == 'Center') {
            fwrite($style, "margin: auto;\n}\n");
        }
        if ($_POST['cont_align'] == 'Left') {
            fwrite($style, "margin-left: 0;\n}\n");
        }
        if ($_POST['cont_align'] == 'Right') {
            fwrite($style, "position: fixed;\nright: 0;\n}\n");
        }

    }

    //If container is set to be fluid
    if ($_POST['container_type'] == "Fluid") {
        $container_max_width = $_POST['max-width'];
        $container_min_width = $_POST['min-width'];
        fwrite($style, ".maincontainer{\nmax-width: " . $container_max_width . "px;\n");
        fwrite($style, "min-width: " . $container_min_width . "px;\n margin: auto;\n}\n");
    }

    //Adding navbar/header
    if ($_POST['nav_check'] == 1 && array_key_exists('nav_check', $_POST)) {
        fwrite($show, "<div class=\"navbar\">\n<div>\n<div class=\"nav-head\">Website name</div>\n");
        $nav_height = $_POST['nav_height'];
        $nav_color = $_POST['nav_color'];
        $nav_padding = $nav_height*0.66666666666667;
        fwrite($style, ".navbar{\n height: " . $nav_height . "px;\n background-color: #" . $nav_color . ";\n padding: " . $nav_padding . "px\n}\n.nav-head{\nfloat:left;\n}\n");

        if ($_POST['nav_menu'] == 1 && array_key_exists('nav_menu', $_POST)) {
            fwrite($show, "<div class=\"menu nav-items\">\n<li>Home</li>\n<li>Products</li>\n<li>Blog</li>\n</div>\n");
            fwrite($style, ".nav-items{\npadding: 0 10px;\n}\n.nav-items li{\n display: inline-block;\n padding:0 20px; \nfloat: right;\n}\n");
        }
        fwrite($show, "</div>\n</div>\n");
    }

    //Adding side menu
    $side_width = $_POST['side_width'];
    if ($_POST['side_check'] == 1 && array_key_exists('side_check', $_POST)) {

        fwrite($show, "<div class=\"sidemenu\">\n<ul>\n<h3>Main</h3>\n<li>Lorem ipsum.</li>\n<li>Non, optio!</li>\n<li>Asperiores, nesciunt?</li>\n</ul>\n</div>\n");
        $side_width = $_POST['side_width'];
        $side_color = $_POST['side_color'];
        if ($_POST['side_align'] == 'Left') {
            fwrite($style, ".sidemenu{\npadding:20px;\nbackground-color: #" . $side_color . ";\nfloat: left;\nwidth: " . $side_width . "px;\nheight:500px;\n}\n");
        }
        if ($_POST['side_align'] == 'Right') {
            fwrite($style, ".sidemenu{\npadding:20px;\nbackground-color: #" . $side_color . ";\nfloat: right;\nwidth: " . $side_width . "px;\nheight:500px;\n}\n");
        }

    }
    //Adding main container
    fwrite($show, "<div class=\"main-content\">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam dignissimos doloremque error, et harum
        illum ipsum nesciunt nihil nobis quam repellendus sit sunt unde, vero vitae voluptatem! Aliquid, asperiores
        perspiciatis. Cumque dicta eum, fuga harum maxime quos reiciendis. Accusamus aliquid architecto deleniti ea,
        eos, inventore modi praesentium quae quia, reiciendis rem reprehenderit suscipit tempore. Dignissimos dolores ex
        iusto magnam magni placeat quod recusandae ut voluptatibus? Ab deleniti fugit perferendis, quae quibusdam
        tenetur vel. Corporis culpa eum iste nemo obcaecati, perferendis qui quod sed sunt voluptatibus. Accusamus at
        autem delectus distinctio, doloribus esse magnam pariatur, perspiciatis quia ratione repellat sapiente.
        <br><br>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda delectus dolor ipsum minus molestias sit,
        vel voluptas? Ab aliquid atque cumque dolores error, illo, inventore itaque laboriosam laudantium neque nesciunt
        quaerat quas quibusdam quo recusandae voluptas voluptatibus! A cumque deleniti, doloremque eligendi fugit harum
        minima modi, odio odit quia vero voluptas voluptate. Architecto, eius explicabo molestias natus quam repellat
        sit veritatis! Corporis soluta, voluptatum? Hic iusto possimus rem totam voluptates?
    </div>\n");

    //Managing alignment of main container
    $main_content_color = $_POST["main_content_color"];
    fwrite($style, ".main-content {\npadding: 20px;\nbackground-color: #" . $main_content_color . ";\nheight: 500px;\nmargin:auto;\n}\n");
    if ($_POST['side_align'] == 'Left' && $_POST['side_check'] == 1) {
        fwrite($style, ".main-content {\npadding: 20px;\nbackground-color: #" . $main_content_color . ";\nheight: 500px;\nmargin-left:" . ($side_width + 40) . "px;\n}\n");
    }
    if ($_POST['side_align'] == 'Right') {
        fwrite($style, ".main-content {\npadding: 20px;\nbackground-color: #" . $main_content_color . ";\nheight: 500px;\nmargin-right:" . ($side_width + 40) . "px;\n}\n");
    }
    //Adding footer
    if ($_POST['footer_check'] == 1 && array_key_exists('footer_check', $_POST)) {

        fwrite($show, "<footer class=\"footer\">\nFooter\n</footer>\n");
        $footer_height = $_POST['footer_height'];
        $footer_color = $_POST['footer_color'];
        fwrite($style, ".footer{\n height: " . $footer_height . "px;\n background-color: #" . $footer_color . ";\n padding: 20px;\ntext-align: center;\n}\n");

    }

    //Closing of files here
    fwrite($show, "</div>\n</body>\n</html>\n");
    fclose($show);
    fclose($style);
    $_SESSION['submitted'] = true;

    //After checking, go to show and download of layout
    header('location:Layout_show_download.php');
}

?>
