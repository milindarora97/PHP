<?php
@session_start();
error_reporting(!E_NOTICE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Theme Generator</title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<body>
<style>
    body {
        background-image: url("Trees_1920x1234.png");
        font-family: 'Raleway', sans-serif;
    }

    .navbar-active {
        display: none;
    }

    .header-active {
        display: none;
    }

    .footer-active {
        display: none;
    }

    .sidebar-active {
        display: none;
    }

    .sidebar-left-active {
        display: none;
    }

    .sidebar-right-active {
        display: none;
    }
</style>
<br>
<div class="container">
    <div class="row">
        <div class="col-md-8 card" style="background-color: mintcream">
            <form action="submit.php" method="post" enctype="multipart/form-data">
                <?php
                if (isset($_POST['submit-welcome'])) {
                    ?>
                <br>
                    <h1 style="color:lightseagreen"> Hi <?= $_POST['user']; ?>,<br> Please let us know your preferences
                    </h1>
                <?php }
                ?>
                <div class="card-header">
                    <label for="title">Give a Title:
                        <input type="text" name="title" id="title" placeholder="Your Tab Display Name"
                               class="form-control">
                    </label>
                </div>
                <div class="card-header">
                    <div class="form-group">
                        <label for="font">Select Font-Style:</label>
                        <select class="form-control" id="font" name="font">
                            <option>Calibri</option>
                            <option>sans-serif</option>
                            <option>Algerian</option>
                            <option>monospace</option>
                            <option>fantasy</option>
                            <option>system-ui</option>
                            <option>Comic Sans MS</option>
                            <option>Freestyle Script</option>
                            <option>Arial</option>
                            <option>Berlin Sans</option>
                            <option>Calibri</option>
                            <option>Calibri Light</option>
                            <option>Cambria</option>
                            <option>Times New Roman</option>
                            <option>Constantia</option>
                            <option>sarif</option>
                            <option>Roboto</option>
                            <option>Ravie</option>
                            <option>Lucida Bright</option>
                            <option>Rockwell</option>
                            <option>Raleway</option>
                            <option>Courier New</option>
                            <option>Georgia</option>
                            <option>Impact</option>
                            <option>Gadugi</option>
                            <option>Marlett</option>
                            <option>Menlo</option>
                            <option>Fira Code</option>
                            <option>Droid Sans</option>
                            <option>Chiller</option>
                            <option>Forte</option>
                            <option>Elephant</option>
                            <option>Cooper Black</option>
                            <option>Jokerman</option>
                        </select>
                    </div>
                </div>
                <div class="card-header">
                    <label for="background">Select Background Style</label>
                    <div class="form-check">
                        <label class="form-check-label" for="radio10">
                            <input type="radio" name="radioback" id="radio10" value="radio10">
                            Solid
                        </label>
                    </div>
                    <div id="colorbackground">
                        <label for="colorback">Choose Background Color
                            <input type="color" name="colorback" id="colorback" value="#FFFFF0"
                                   class="card-img">
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label" for="radio11">
                            <input type="radio" name="radioback" id="radio11" value="radio11">
                            Image
                        </label>
                    </div>
                    <div id="imagebackground">
                        <label for="imageback">Choose Background Image
                            <input type="file" id="imageback" name="imageback">
                        </label>
                    </div>
                </div>
                <div class="card-header">
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" id="check1" name="check1" value="check1">
                            Include Navbar
                        </label>
                    </div>
                    <div class="navbar-active">
                        <label for="positionnav">Select Position</label>
                        <div class="form-check">
                            <label class="form-check-label" for="radio1">
                                <input type="radio" name="radio" id="radio1" value="radio1" checked>
                                Top
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label" for="radio2">
                                <input type="radio" name="radio" id="radio2" value="radio2">
                                Bottom
                            </label>
                        </div>
                        <div>
                            <label for="colornav">Select Color
                                <input type="color" name="colornav" id="colornav" value="#8ECC8E" class="card-img">
                            </label>
                        </div>
                        <div>
                            <label for="titlenav">Enter Comapany Title
                                <input type="text" name="titlenav" id="titlenav" placeholder="Ex: Google">
                            </label>
                        </div>
                        <div>
                            <label for="menunav">Enter Menu:
                                <input type="text" name="menunav1" id="menunav1" placeholder="Option 1"
                                       class="form-control">
                                <input type="text" name="menunav2" id="menunav2" placeholder="Option 2"
                                       class="form-control">
                                <input type="text" name="menunav3" id="menunav3" placeholder="Option 3"
                                       class="form-control">
                            </label>
                        </div>
                        <div>
                            <label for="searchnav">Do you want the search option?
                                <input type="radio" name="searchnav" id="searchnav1" value="yes" checked>Yes
                                <input type="radio" name="searchnav" id="searchnav2" value="no">No
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-header">
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" id="check2" name="check2">
                            Include Header
                        </label>
                    </div>
                    <div class="header-active">
                        <div>
                            <label for="height">Select Height (px)
                                <input type="number" height="pixels" name="height" id="height" value="160">
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label" for="radio8">
                                <input type="radio" name="radioheader" id="radio8" value="radio8">
                                Solid
                            </label>
                        </div>
                        <div id="colorhead">
                            <label for="color">Select Background Color
                                <input type="color" name="colorheader" id="colorheader" value="#F3ECEF"
                                       class="card-img">
                            </label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label" for="radio9">
                                <input type="radio" name="radioheader" id="radio9" value="radio9">
                                Image
                            </label>
                        </div>
                        <div id="imagehead">
                            <label for="imageheader">Select Background Image
                                <input type="file" id="imageheader" name="imageheader">
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-header">
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" id="check3" name="check3">
                            Include Footer
                        </label>
                    </div>
                    <div class="footer-active">
                        <div>
                            <label for="heightfooter">Select Height (px)
                                <input type="number" height="pixels" name="heightfooter" id="heightfooter" value="130">
                            </label>
                        </div>
                        <div>
                            <label for="colorfooter">Select Color
                                <input type="color" name="colorfooter" id="colorfooter" value="#F3ECEF"
                                       class="card-img">
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-header">
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" id="check4" name="check4">
                            Include SideBar
                        </label>
                    </div>
                    <div class="sidebar-active">
                        <legend>Select Position</legend>
                        <div class="form-check">
                            <label class="form-check-label" for="checkleft">
                                <input type="checkbox" class="form-check-input" id="checkleft" name="checkleft"
                                       value="optionleft">
                                Left Column
                            </label>
                        </div>
                        <div class="sidebar-left-active">
                            <div>
                                <label for="heightleft">Select Width (px)
                                    <input type="number" height="pixels" name="heightleft" id="heightleft"
                                           value="120">
                                </label>
                            </div>
                            <div>
                                <label for="colorleft">Select Color
                                    <input type="color" name="colorleft" id="colorleft" value="#E5FFE5"
                                           class="card-img">
                                </label>
                            </div>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label" for="checkright">
                                <input type="checkbox" class="form-check-input" id="checkright" name="checkright"
                                       value="optionright">
                                Right Column
                            </label>
                        </div>
                        <div class="sidebar-right-active">
                            <div>
                                <label for="heightright">Select Width (px)
                                    <input type="number" height="pixels" name="heightright" id="heightright"
                                           value="120">
                                </label>
                            </div>
                            <div>
                                <label for="colorright">Select Color
                                    <input type="color" name="colorright" id="colorright" value="#E5FFE5"
                                           class="card-img">
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="modal-content">
                    <button type="submit" name="submit" class="btn btn-outline-primary">Submit</button>
                </div>
                <br>
            </form>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {

        $("input[name='check1']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".navbar-active").show();
            } else {
                $(".navbar-active").hide();
                $("input[name='radio']").prop("checked", "checked");
            }
        });
        $("input[name='check2']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".header-active").show();
            } else {
                $(".header-active").hide();
                $("input[name='header']").prop("checked", "checked");
            }
        });
        $("input[name='check3']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".footer-active").show();
            } else {
                $(".footer-active").hide();
                $("input[name='footer']").prop("checked", "checked");
            }
        });
        $("input[name='check4']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".sidebar-active").show();
            } else {
                $(".sidebar-active").hide();
                $("input[name='sidebar']").prop("checked", "checked");
            }
        });
        $("input[name='checkleft']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".sidebar-left-active").show();
            } else {
                $(".sidebar-left-active").hide();
                $("input[name='sidebarinside']").prop("checked", "checked");
            }
        });
        $("input[name='checkright']").on("change", function () {
            var isChecked = $(this).prop("checked");
            if (isChecked) {
                $(".sidebar-right-active").show();
            } else {
                $(".sidebar-right-active").hide();
                $("input[name='sidebarinside']").prop("checked", "checked");
            }
        });
    });
    $(document).ready(function () {
        $("#colorhead").hide();
        $("#imagehead").hide();
        $("#radio8").click(function () {
            $("#colorhead").toggle();
        });
        $("#radio9").click(function () {
            $("#imagehead").toggle();
        });
        $("#colorbackground").hide();
        $("#imagebackground").hide();
        $("#radio10").click(function () {
            $("#colorbackground").toggle();
        });
        $("#radio11").click(function () {
            $("#imagebackground").toggle();
        });
    });
</script>
</body>
</html>