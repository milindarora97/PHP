<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Theme Generator</title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
    body {
        background-image: url("Trees_1920x1234.png");
        font-family: 'Raleway', sans-serif;
    }

    .card {
        margin-top: 18%;
        background-color: mintcream;
    }
</style>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12 card" style="text-align: center">
            <form method="post" action="welcome.php">
                <br>
                <h1 style="color: lightseagreen">Welcome</h1>
                <div class="form-group">
                    <input type="text" name="user" class="form-control" placeholder="Please enter your name">
                </div>
                <div class="modal-content">
                    <button type="submit" name="submit-welcome" class="btn btn-primary">Submit</button>
                </div>
                <br><br>
            </form>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>