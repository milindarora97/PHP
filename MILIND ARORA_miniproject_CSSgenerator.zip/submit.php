<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $_POST['title']; ?></title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
    #download {
        background-color: black;
        color: ivory;
        font-family: 'Raleway', sans-serif;
    }
</style>
<body>
<div id="download" style="margin: auto">
    Are you satisfied with your make?
    <a href="test.zip" download class="download_file"> Download Files</a> or
    <a href="welcome.php"> Go Back</a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php
@session_start();
error_reporting(!E_NOTICE);
if (isset($_POST['submit'])) {
    $show = fopen("download_show.html", "w") or die("Unable to open file!");
    $style = fopen("download_style.css", "w");
    fwrite($show, "<!-- For proper functioning,css and js directories should be kept within the same project as per the specified path -->\n");
    fwrite($show, "<!DOCTYPE html>\n<html lang=\"en\">\n");
    $title = $_POST['title'];
    $font = $_POST['font'];
    $colorback = $_POST['colorback'];
    fwrite($show, "<head>\n <meta charset=\"UTF-8\">\n <title>" . $title . "</title>\n </head>\n<link rel=\"stylesheet\" href=\"download_style.css\">\n");
    fwrite($show, "<link rel=\"stylesheet\" href=\"css/animate.css\">\n<link rel=\"stylesheet\" href=\"css/bootstrap.css\">\n");
    fwrite($show, "<body>\n<div class=\"maincontainer\">\n");
    if ($_POST['radioback'] == 'radio11') {
        function completeupload($file)
        {
            $status = move_uploaded_file($file['tmp_name'], '' . $file['name']);
        }

        if (count($_FILES) > 0) {
            $f = $_FILES['imageback'];
            if ($f['error'] == 0) {
                if ($f['type'] == "image/jpg" || $f['type'] == "image/jpeg") {
                    completeupload($f);
                } else
                    echo "<p class='alert alert-danger'>Not a jpeg Image</p>";
            } else
                echo "<p class='alert alert-danger'>The file could not be uploaded</p>";
        }
        $f = $_FILES['imageback'];
        $n = $f['name'];
        fwrite($style, "#content, .maincontainer {\n background-image:url(" . $n . ");<!-- The image should be present in the same folder as this --> \n");
    } else {
        fwrite($style, "#content, .maincontainer {\n background-color:" . $colorback . ";\n");
    }
    fwrite($style, "margin: auto;\n");
    fwrite($style, "font-family:" . $font . ";\n}");

    if (isset($_POST['check1'])) {
        if ($_POST['radio'] == 'radio2') {
            include_once 'navbarbottom.php';
            fwrite($show, "<nav class=\"navbar navbar-toggleable-md navbar-light fixed-bottom\">\n");
            fwrite($show, "<button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"aria-label=\"Toggle navigation\">\n");
            fwrite($show, " <span class=\"navbar-toggler-icon\"></span>\n</button>\n");
            fwrite($show, "<a class=\"navbar-brand\" href=\"#\">" . $titlenav . "</a>\n");
            fwrite($show, " <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n");
            fwrite($style, "\n nav {\n background-color: " . $colornav . ";\n position:static; \n}\n");
            fwrite($show, "<ul class=\"navbar-nav mr-auto\">\n<li class=\"nav-item active\">\n");
            fwrite($show, "<a class=\"nav-link\" href=\"#\">" . $menunav1 . "<span class=\"sr-only\">(current)</span></a>\n</li>\n");
            fwrite($show, "<li class=\"nav-item\">\n <a class=\"nav-link\" href=\"#\">" . $menunav2 . "</a>\n</li>\n");
            fwrite($show, "<li class=\"nav-item\">\n <a class=\"nav-link\" href=\"#\">" . $menunav3 . "</a>\n</li>\n</ul>\n");
            if ($_POST['searchnav'] == 'yes') {
                fwrite($show, "<form class=\"form-inline my-2 my-lg-0\">\n");
                fwrite($show, " <input class=\"form-control mr-sm-2\" type=\"text\" placeholder=\"Search\">\n");
                fwrite($show, " <button class=\"btn btn-outline-primary my-2 my-sm-0\" type=\"submit\">Search</button>");
                fwrite($show, "\n</form>\n");
            }
            fwrite($show, "</div>\n</nav>\n");
        }
        if ($_POST['radio'] == 'radio1') {
            include_once 'navbartop.php';
            fwrite($show, "<nav class=\"navbar navbar-toggleable-md navbar-light\">\n");
            fwrite($show, "<button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\"aria-label=\"Toggle navigation\">\n");
            fwrite($show, " <span class=\"navbar-toggler-icon\"></span>\n</button>\n");
            fwrite($show, "<a class=\"navbar-brand\" href=\"#\">" . $titlenav . "</a>\n");
            fwrite($show, " <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n");
            fwrite($style, "\n nav {\n background-color: " . $colornav . ";\n position:static; \n}\n");
            fwrite($show, "<ul class=\"navbar-nav mr-auto\">\n<li class=\"nav-item active\">\n");
            fwrite($show, "<a class=\"nav-link\" href=\"#\">" . $menunav1 . "<span class=\"sr-only\">(current)</span></a>\n</li>\n");
            fwrite($show, "<li class=\"nav-item\">\n <a class=\"nav-link\" href=\"#\">" . $menunav2 . "</a>\n</li>\n");
            fwrite($show, "<li class=\"nav-item\">\n <a class=\"nav-link\" href=\"#\">" . $menunav3 . "</a>\n</li>\n</ul>\n");
            if ($_POST['searchnav'] == 'yes') {
                fwrite($show, "<form class=\"form-inline my-2 my-lg-0\">\n");
                fwrite($show, " <input class=\"form-control mr-sm-2\" type=\"text\" placeholder=\"Search\">\n");
                fwrite($show, " <button class=\"btn btn-outline-primary my-2 my-sm-0\" type=\"submit\">Search</button>\n");
                fwrite($show, "</form>\n");
            }
            fwrite($show, "</div>\n</nav>\n");
        }
    }

    if (isset($_POST['check2'])) {
        include_once 'header.php';
        if ($_POST['radioheader'] == 'radio9') {
            function completeuploads($filehead)
            {
                $status = move_uploaded_file($filehead['tmp_name'], '' . $filehead['name']);
            }

            if (count($_FILES) > 0) {
                $fh = $_FILES['imageheader'];
                if ($fh['error'] == 0) {
                    if ($fh['type'] == "image/jpg" || $fh['type'] == "image/jpeg") {
                        completeuploads($fh);
                    } else
                        echo "<p class='alert alert-danger'>Not a jpeg Image</p>";
                } else
                    echo "<p class='alert alert-danger'>The file could not be uploaded</p>";
            }
            fwrite($style, "\n header{\n background-image:url(" . $nh . "); <!-- The image should be present in the same folder as this -->\n");
        } else {
            fwrite($style, "\n header{\n background-color:" . $colorheader . ";\n");
        }
        fwrite($style, "overflow: hidden;\n height:" . $height . "px;\n");
        fwrite($style, "font-family:" . $font . ";\n}");
        fwrite($show, "<header>\n <h1>Most important heading here</h1>\n<h3>Less important heading here</h3>\n<p>Some additional information here</p>");
        fwrite($show, "\n</header>\n");
    }
    if (isset($_POST['check3'])) {
        include_once 'footer.php';
        fwrite($style, "\n footer{\n background-color:" . $colorfooter . ";\n");
        fwrite($style, "overflow: hidden;\n height:" . $heightfooter . "px;\n");
        fwrite($style, "font-family:" . $font . ";\n width:100%;\n bottom:0;\n position:fixed;\n }");
        fwrite($show, "<footer>\n <h6>Contact Us-</h6><p>Contact information:<a href=\"mailto:someone@example.com\">someone@example.com</a>.</p>");
        fwrite($show, "\n</footer>\n");
    }
    if (isset($_POST['check4'])) {
        if ($_POST['checkleft'] == 'optionleft') {
            include_once 'sidebarleft.php';
            fwrite($style, "\n #leftcolumn {\n background-color:" . $colorleft . ";\n");
            fwrite($style, "overflow: hidden;\n width:" . $heightleft . "px;\n");
            fwrite($style, "font-family:" . $font . ";\n float:left;\n }");
            fwrite($show, "<div id=\"leftcolumn\" class=\"card-img-bottom\">\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum.Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis </p>");
            fwrite($show, "\n</div>\n");
        }
        if ($_POST['checkright'] == 'optionright') {
            include_once 'sidebarright.php';
            fwrite($style, "\n #rightcolumn {\n background-color:" . $colorright . ";\n");
            fwrite($style, "overflow: hidden;\n width:" . $heightright . "px;\n");
            fwrite($style, "font-family:" . $font . ";\n float:right;\n }");
            fwrite($show, "<div id=\"rightcolumn\" class=\"card-img-bottom\">\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum.Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis </p>");
            fwrite($show, "\n</div>\n");
        }
    }
    include_once 'basic.php';
    fwrite($show, "<div class=\"content\" id=\"content\">\n");
    fwrite($show, " Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae.");
    fwrite($show, "\n</div>\n");
    fwrite($show, "</div>\n");
    fwrite($show, "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n<script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\"integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\"crossorigin=\"anonymous\"></script>\n<script src=\"js/bootstrap.min.js\"></script>");
    fwrite($show, "\n</body>\n</html>\n");
    fclose($show);
    fclose($style);
}
$zip = new ZipArchive();
$filename = "test.zip";
if ($zip->open($filename, ZipArchive::CREATE) !== true) {
    exit("cannot open <$filename>\n");
}
$zip->addFile("download_show.html", "download_show.html");
$zip->addFile("download_style.css", "download_style.css");
$zip->addFile("$n", "$n");
$zip->addFile("$nh", "$nh");
$zip->addFile("css/animate.css", "css/animate.css");
$zip->addFile("css/bootstrap.css", "css/bootstrap.css");
$zip->addFile("css/bootstrap-grid.css", "css/bootstrap-grid.css");
$zip->addFile("css/bootstrap-reboot.css", "css/bootstrap-reboot.css");
$zip->addFile("css/stylex.css", "css/stylex.css");
$zip->addFile("js/bootstrap.js", "js/bootstrap.js");
$zip->addFile("js/bootstrap.js/bootstrap.min.js", "js/bootstrap.js/bootstrap.min.js");
$zip->close();
?>



