<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $_POST['title']; ?></title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<?php
$colorback = $_POST['colorback'];
$f = $_FILES['imageback'];
$n = $f['name'];
$font = $_POST['font'];
?>
<style>
    #content {
        font-family: <?= $font;?>;
        background-image: url("<?= $n; ?>");
        background-color: <?= $colorback ?>;
    }
</style>
<body>
<div class="content" id="content">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
    molestiae molestias nemo neque nesciunt, nulla quas repellendus tempora totam. Lorem ipsum dolor sit amet,
    consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi assumenda ea illum laborum mollitia
    nesciunt nulla quae, qui quis voluptas! Aliquid cumque fuga fugiat nemo numquam quod saepe soluta
    ut.Adipisci dolorum illo laborum
    nulla sapiente. Aut beatae consequuntur, dicta distinctio illo minima provident quas sed soluta temporibus
    ullam
    unde, vel veniam? Accusamus alias est laudantium nam nostrum sint tempore!Amet delectus dolorem fugiat illum
    ipsum
    optio quaerat vitae. Aliquam consequatur consequuntur cumque distinctio dolor doloribus eius expedita ipsam
    labore
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>