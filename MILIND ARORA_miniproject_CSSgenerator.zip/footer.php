<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $_POST['title'];?></title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:600" rel="stylesheet">
<?php
$heightfooter = $_POST['heightfooter'];
$colorfooter = $_POST['colorfooter'];
?>
<style>
    footer {
        font-family: <?=$_POST['font'];?>;
        position:fixed;
        bottom:0;
        width:100%;
        background-color: <?= $colorfooter ?>;
        height: <?= $heightfooter ?>px;
        overflow: hidden;
    }
</style>
<body>
<footer>
    <h6>Contact Us-</h6>
    <p>Contact information: <a href="mailto:someone@example.com">
            someone@example.com</a>.</p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>