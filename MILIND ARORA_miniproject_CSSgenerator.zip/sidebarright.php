<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $_POST['title']; ?></title>
</head>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:600" rel="stylesheet">
<?php
$heightright = $_POST['heightright'];
$colorright = $_POST['colorright'];
?>
<style>
    #rightcolumn {
        font-family: <?=$_POST['font'];?>;
        background-color: <?= $colorright ?>;
        width: <?= $heightright ?>px;
        float: right;
        overflow: hidden;
    }
</style>
<body>
<div id="rightcolumn" class="card-img-bottom">
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum.Sed cursus ante
        dapibus diam. Sed nisi. Nulla quis sem Nulla quis sem at nibh elementum </p>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>